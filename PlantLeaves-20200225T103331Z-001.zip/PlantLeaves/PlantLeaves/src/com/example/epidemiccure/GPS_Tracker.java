package  com.example.epidemiccure;

import android.app.AlertDialog;
import android.app.Service;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.audiofx.BassBoost;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
//import android.support.annotation.Nullable;
//import android.support.v7.app.AlertDialog;
import android.util.Log;

import static android.location.LocationManager.*;

/**
 * Created by xyz on 10/26/2016.
 */

public class GPS_Tracker extends Service implements LocationListener {

    private final Context myContext;
    boolean isGPSEnable = false;
    boolean isNetworkEnabled = false;
    boolean canGetLocation = false;
    Location location;
    private double latitude, longitude;
    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATE = 10, MIN_TIME_BW_UPDATE = 1000 * 60 * 1;
    LocationManager locationManager;

    public GPS_Tracker(Context context){
        this.myContext = context;
        getLocation();
    }

    public Location getLocation(){
        try {
            locationManager = (LocationManager) myContext.getSystemService(LOCATION_SERVICE);
            isGPSEnable = locationManager.isProviderEnabled(GPS_PROVIDER);
            isNetworkEnabled = locationManager.isProviderEnabled(NETWORK_PROVIDER);
            if (!isGPSEnable && !isNetworkEnabled) {

            } else {
                this.canGetLocation = true;
                if (isNetworkEnabled) {
                    locationManager.requestLocationUpdates(NETWORK_PROVIDER, MIN_TIME_BW_UPDATE, MIN_DISTANCE_CHANGE_FOR_UPDATE, this);
                    Log.d("Network", "Network");
                    if (locationManager != null) {
                        location = locationManager.getLastKnownLocation(NETWORK_PROVIDER);
                        latitude = location.getLatitude();
                        longitude = location.getLongitude();
                    }
                }
            }
            if (isGPSEnable) {
                if (location == null) {
                    locationManager.requestLocationUpdates(NETWORK_PROVIDER, MIN_TIME_BW_UPDATE, MIN_DISTANCE_CHANGE_FOR_UPDATE, this);
                    if (locationManager != null) {
                        location = locationManager.getLastKnownLocation(GPS_PROVIDER);
                        if (location != null) {
                            latitude = location.getLatitude();
                            longitude = location.getLongitude();
                        }
                    }
                }
            }
        }catch (SecurityException e) {
            e.printStackTrace(); // lets the user know there is a problem with the gps
        }catch (Exception e){
            e.printStackTrace();
        }
        return location;
    }

   /* public void stopUsingGps(){
        try {
            if(locationManager != null){
                locationManager.removeUpdates();
            }
        }catch (SecurityException e){
            e.printStackTrace();
        }
    }*/

    public double getLatitude(){
        if(location!=null){
            latitude = location.getLatitude();
        }
        return latitude;
    }

    public double getLongitude(){
        if(location!=null){
            longitude = location.getLongitude();
        }
        return longitude;
    }

    public boolean canGetLocation(){
        return this.canGetLocation;
    }

    public void showSettingsAlert(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(myContext);
        builder.setTitle("GPS Settings");
        builder.setMessage("GPS is not enabled. Please enable it from settings");
        builder.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                myContext.startActivity(intent);
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

 
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
