package com.example.epidemiccure;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Comment extends Activity implements OnClickListener{
	String connectionstring="Data Source=64.71.180.27;User ID=opass_123;Password=pass_123";  
	EditText name,email,comment;
	Button btncomment;
	ProgressDialog dialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.comment);
		
		name=(EditText)findViewById(R.id.input_name);
		email=(EditText)findViewById(R.id.input_email);
		comment=(EditText)findViewById(R.id.input_comment);
		
		btncomment=(Button)findViewById(R.id.btn_comment);
		btncomment.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				runOnUiThread(new Runnable() {
					public void run() {
						//register();
						
						Comment1 w = new Comment1();
						w.execute();
						
					}
				});
			}
		});
		
	}
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	class Comment1 extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... arg0) {
			
			if(name.getText().toString()!=null && email.getText().toString()!=null && comment.getText().toString()!=null)
			{			
				//dialog=ProgressDialog.show(Comment.this,"", "Progress....", true);
				Webservice com=new Webservice();
				String ss="Insert into Plant_Comment1 values('"+name.getText().toString()+"','"+email.getText().toString()+"','"+comment.getText().toString()+"')";
				final String result=com.Employee("CommonQuery1",connectionstring, ss);	
				
				runOnUiThread(new Runnable() {
					
					@Override
					public void run()
					{
							// TODO Auto-generated method stub
						Toast.makeText(Comment.this, ""+result, Toast.LENGTH_LONG).show();	
						if(result.toLowerCase().trim().equals("registration completed"))
						{}
						else
						{					//Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
						}
					}
				});
			}
			//dialog.dismiss();
			
			return null;
		}
	}
}
