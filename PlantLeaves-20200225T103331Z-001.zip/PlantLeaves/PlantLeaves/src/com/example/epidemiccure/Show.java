package com.example.epidemiccure;

import android.R.string;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Show extends Activity implements OnClickListener {
	String thresh="";
	String foo="";
	String connectionstring="Data Source=64.71.180.27;User ID=opass_123;Password=pass_123";   

	
	 String pname="";
	
	 public static String emailpatient;
	 public static String emaildis;
	 public static String emailaddress;
	 public static String emailper;
	 Button btn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.show);
		
		
		 thresh=Segmentation.newthresh1.toString().trim();
		 pname=Login.user.toString().trim();
		 foo=UploadImage.filename1.toString().trim();

		
		//Toast.makeText(getApplicationContext(), pname, Toast.LENGTH_LONG).show(); 
	
		//Toast.makeText(getApplication(), "Done", Toast.LENGTH_LONG).show();
	
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub	
				
		    Postnew();
			Post();
			Postmail();
			postper();
				
			}
		}).start();	
		
		
		 btn=(Button)findViewById(R.id.btnsend);
		 btn.setOnClickListener(this);
		 

	}

	public void Postnew()
	{					
			Webservice com=new Webservice();
			//String idd1="select disease,solution from Epidemic where thresh='"+ thresh+"' and imagename='"+foo+ "'";
			String idd1="select disease,solution from PlantLeaves_Upload where thresh='"+ "0.90" +"' and imagename='"+foo+ "'";
			final String result= com.Employee("SelectQuery1",connectionstring, idd1);
			//dialog.dismiss();
			runOnUiThread(new Runnable() {		
				@Override
				public void run() {
			
					//Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
					TextView tx=(TextView)findViewById(R.id.txtview);
					
					//Toast.makeText(getApplicationContext(), "Done", Toast.LENGTH_LONG).show();
//					
					Typeface custom_font = Typeface.createFromAsset(getAssets(), "ANKIT.TTF");
					tx.setTypeface(custom_font);
					//Log.d("Message2 : " , "Message2");
					//Toast.makeText(getApplicationContext(), "Done1", Toast.LENGTH_LONG).show();
					
					
					Log.e("TTaxiDetails", result);
					 String reportinfo=result;
					
					String[] split=reportinfo.split("~");
					String text=split[0].toString()+"\n"+ split[1].toString();
					//String text="Disease Name : " + split[0].toString()+"\n"+"Soluation : "+ split[1].toString();
					Log.e("length",String.valueOf(split.length));
					
					//tx.setTypeface(Typeface.);
					
					
				
					
					
					tx.setText(text);
					emaildis=tx.getText().toString().trim();
					// dynamic textview
					
					
					
					ArrayAdapter<String> adapter=new ArrayAdapter<String>(Show.this, R.layout.show,split);
					
					
			   }
		});
	} 

	
	
	public void Post()
	{					
			Webservice com=new Webservice();
			String idd1="select fname,mobile from PlantLeaves_Registration where username='"+ pname +"'";
			final String result= com.Employee("SelectQuery1",connectionstring, idd1);
			//dialog.dismiss();
			runOnUiThread(new Runnable() {		
				@Override
				public void run() {
			// TODO Auto-generated method stub
					//Toast.makeText(getApplication(), ""+result, Toast.LENGTH_LONG).show();
					
					TextView name=(TextView)findViewById(R.id.txtname);
					Log.e("TTaxiDetails", result);
					 String reportinfo=result;
					
					String[] split=reportinfo.split("~");
					String text="name : " + split[0].toString()+"\n"+"Mobile no : "+ split[1].toString();
					Log.e("length",String.valueOf(split.length));
					
				
					name.setText(text);
					emailpatient=name.getText().toString().trim();
					
					ArrayAdapter<String> adapter=new ArrayAdapter<String>(Show.this, R.layout.show,split);
				

					
					
			   }
		});
	} 

	
	public void Postmail()
	{					
			Webservice com=new Webservice();
			String idd1="select email from PlantLeaves_Registration where username='"+ pname +"'";
			final String result= com.Employee("SelectQuery1",connectionstring, idd1);
			//dialog.dismiss();
			runOnUiThread(new Runnable() {		
				@Override
				public void run() {
			// TODO Auto-generated method stub
				//	Toast.makeText(getApplication(), ""+result, Toast.LENGTH_LONG).show();
					
					
					TextView mail=(TextView)findViewById(R.id.txtemail);
					Log.e("TTaxiDetails", result);
					 String reportinfo=result;
										
					String text=reportinfo;					
				
					mail.setText(text);
					emailaddress=mail.getText().toString().trim();
			   }
		});
	} 
	
	
	public void postper()
	{					
			Webservice com=new Webservice();
			String idd1="select percentage from PlantLeaves_Upload where thresh='"+ "0.90"+"' and imagename='"+foo+ "'";
			final String result= com.Employee("SelectQuery1",connectionstring, idd1);
			//dialog.dismiss();
			runOnUiThread(new Runnable() {		
				@Override
				public void run() {
			// TODO Auto-generated method stub
					//Toast.makeText(getApplication(), ""+result, Toast.LENGTH_LONG).show();
					
					TextView per=(TextView)findViewById(R.id.txtper);
					Log.e("TTaxiDetails", result);
					 String reportinfo=result;					
					
					String text=reportinfo;					
				
					per.setText(text);
					emailper=per.getText().toString().trim();
			   }
		});
	} 
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.show, menu);
		return true;
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
         if(v.getId()==R.id.btnsend)
         {            	 
        	 Intent i =new Intent(Show.this,Mail.class);
           	 startActivity(i);	
         }		
	}

}
