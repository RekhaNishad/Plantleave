package com.example.epidemiccureadmin;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class DisplayComment extends Activity{
	
	//  String[] monthsArray = { "JAN", "FEB", "MAR", "APR", "MAY", "JUNE", "JULY","AUG", "SEPT", "OCT", "NOV", "DEC" };
	  private ListView itemListView;	  
	  private ArrayAdapter listarrayAdapter;
	  
	  public static String selectedFromList2 ="";
	  ProgressDialog dialog;
	  
	 
	  	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.items);
		
		
		
		String[] array=Home.result2.toString().split("\n");		
		itemListView = (ListView) findViewById(R.id.listitems);		 
		listarrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, array);
		itemListView.setAdapter(listarrayAdapter);
		
		
		itemListView.setOnItemClickListener(new OnItemClickListener() 
		{		
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3)
			{
				selectedFromList2 =(String) (itemListView.getItemAtPosition(arg2));
				Toast.makeText(getApplicationContext(), "Selected Item : " + selectedFromList2, Toast.LENGTH_LONG).show();
								
				Intent inte=new Intent(DisplayComment.this,Mail.class);
				startActivity(inte);
			}	
		});	
	}

}
