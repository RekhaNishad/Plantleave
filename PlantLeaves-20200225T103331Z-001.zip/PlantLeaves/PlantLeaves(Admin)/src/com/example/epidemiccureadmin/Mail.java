package com.example.epidemiccureadmin;

import android.app.Activity;

import android.content.Intent;

import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Typeface;

import android.net.Uri;

import android.os.Bundle;

import android.provider.MediaStore;

import android.util.Log;

import android.view.View;

import android.view.View.OnClickListener;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;

import android.widget.EditText;

import android.widget.Toast;

 

public class Mail extends Activity implements OnClickListener {
Button newcomment;
EditText editTextEmail, editTextSubject, editTextMessage;
Button btnSend, btnAttachment;
String email, subject, message, attachmentFile;
Uri URI = null;
private static final int PICK_FROM_GALLERY = 101;

int columnIndex;
    //   Bitmap img;
       String mail="";
       String mname="";
       String Diease="";
       String percentage="";
       String msg="This Is your Epidemic Cure Report";
       ImageView img123;
      EditText txtSoluationName;
 

       @Override

       protected void onCreate(Bundle savedInstanceState) {

              super.onCreate(savedInstanceState);

              setContentView(R.layout.mail);

              editTextEmail = (EditText) findViewById(R.id.editTextTo);

              editTextSubject = (EditText) findViewById(R.id.editTextSubject);

              editTextMessage = (EditText) findViewById(R.id.editTextMessage);

              btnAttachment = (Button) findViewById(R.id.buttonAttachment);
              
              txtSoluationName=(EditText)findViewById(R.id.input_DiseaseName);
              Typeface custom_font = Typeface.createFromAsset(getAssets(), "ANKIT.TTF");
              txtSoluationName.setTypeface(custom_font);

              btnSend = (Button) findViewById(R.id.buttonSend);
              
             
              
              String[] data=DisplayComment.selectedFromList2.toString().split("~");
              
              
        //      img123=(ImageView)findViewById(R.id.img123);
             
              
              mail=data[1].toString();
//              mname=Show.emailpatient;
//              Diease=Show.emaildis;
//              percentage=Show.emailper;
              
              
     
			
			
              
              editTextEmail.setText(mail); 
//              editTextMessage.setText(mname +"\n"+" Diease percentage : "+percentage);
//              editTextSubject.setText(msg);
//              
//              txtSoluationName.setText(Diease);

 

            btnSend.setOnClickListener(this);

              btnAttachment.setOnClickListener(this);

       }

 

       protected void onActivityResult(int requestCode, int resultCode, Intent data) {

             if (requestCode == PICK_FROM_GALLERY && resultCode == RESULT_OK) {

                     /**

                      * Get Path

                      */

                     Uri selectedImage = data.getData();

                     String[] filePathColumn = { MediaStore.Images.Media.DATA };

                     Cursor cursor = getContentResolver().query(selectedImage,filePathColumn, null, null, null);

                     cursor.moveToFirst();

                     columnIndex = cursor.getColumnIndex(filePathColumn[0]);

                     attachmentFile = cursor.getString(columnIndex);

                     Log.e("Attachment Path:", attachmentFile);

                       URI = Uri.parse("file://" + attachmentFile);

                     cursor.close();

              }

       }

 

       @Override

       public void onClick(View v) {

 

              if (v == btnAttachment) {

                  openGallery();
            	  
//            	  img=UploadImage.image;
//                  img123.setImageBitmap(img);



              }

             if (v == btnSend) {

                     try {
                    	 
                           
                           email = editTextEmail.getText().toString();

                           subject = editTextSubject.getText().toString();

                           message = editTextMessage.getText().toString();
                           message += txtSoluationName.getText().toString();

 

                           final Intent emailIntent = new Intent(

                                         android.content.Intent.ACTION_SEND);

                           emailIntent.setType("plain/text");

                           emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL,

                                         new String[] { email });

                           emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,

                                         subject);

                           if (URI != null) {

                                  emailIntent.putExtra(Intent.EXTRA_STREAM, URI);

                          }

                           emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, message);

                           this.startActivity(Intent.createChooser(emailIntent,

                                         "Sending email..."));

 

                     } catch (Throwable t) {

                           Toast.makeText(this,

                                         "Request failed try again: " + t.toString(),

                                         Toast.LENGTH_LONG).show();

                     }

              }

 

       }

 

       public void openGallery() {

            Intent intent = new Intent();

             intent.setType("image/*");

              intent.setAction(Intent.ACTION_GET_CONTENT);

              intent.putExtra("return-data", true);

              startActivityForResult(

                           Intent.createChooser(intent, "Complete action using"),

                           PICK_FROM_GALLERY);

 
       }

 

}
