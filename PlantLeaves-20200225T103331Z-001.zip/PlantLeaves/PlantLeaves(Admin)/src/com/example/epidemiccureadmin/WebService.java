package com.example.epidemiccureadmin;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.AndroidHttpTransport;
import android.R.string;

public class WebService {
	private static final String MethodName = null;
	String namespace = "http://tempuri.org/";
    private String url = "http://krivitechnologies.com/Service1.asmx";//"http://www.webservicex.net/ConvertWeight.asmx";
    String SOAP_ACTION;
    SoapObject request = null, objMessages = null;
    SoapSerializationEnvelope envelope;
    AndroidHttpTransport androidHttpTransport;
    
   
    
    public String Employee(String MethodName,String connectionstring,String Query) 
    {
       
      try {
          SOAP_ACTION = namespace + MethodName;
          // SoapObject Request = new SoapObject(name,MethodName);
          //Adding values to request object
          request = new SoapObject(namespace, MethodName);
           
          //Adding Double value to request object
          PropertyInfo weightProp =new PropertyInfo();
          weightProp.setName("connectionstring");
          weightProp.setValue(connectionstring);
          weightProp.getValue();
          weightProp.setType(String.class);
          request.addProperty(weightProp);
               
          PropertyInfo weightProp1 =new PropertyInfo();
          weightProp1.setName("Query");
          weightProp1.setValue(Query);
          weightProp1.setType(String.class);
          request.addProperty(weightProp1);  
          
          SetEnvelope();
           
          try {               
              //SOAP calling webservice
              androidHttpTransport.call(SOAP_ACTION, envelope);
              //Got Webservice response
              String result = envelope.getResponse().toString();
              return result;
          } catch (Exception e) {
              // TODO: handle exception
              return e.toString();
          }
      } catch (Exception e) {
          // TODO: handle exception
          return e.toString();
      }
  }  
    

   
     
  
    public String EpidemicCureSolution(String MethodName,String disease,String solution)
    {
    	try
    	{
    		SOAP_ACTION = namespace + MethodName;
            request = new SoapObject(namespace, MethodName);
            
           
            PropertyInfo weightProp3 =new PropertyInfo();
            weightProp3.setName("disease");
            weightProp3.setValue(disease);
            weightProp3.setType(string.class);
            request.addProperty(weightProp3);
            
            PropertyInfo weightProp4 =new PropertyInfo();
            weightProp4.setName("solution");
            weightProp4.setValue(solution);
            weightProp4.setType(string.class);
            request.addProperty(weightProp4);
    		
    		SetEnvelope();
            
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                String result = envelope.getResponse().toString();
                return result;
            } 
            catch (Exception e) {
           	return e.toString();
            }
            
    	}
    	catch (Exception e) {
            return e.toString();
        }
    }
    
	private void SetEnvelope() {
		// TODO Auto-generated method stub
		try{
            envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            androidHttpTransport = new AndroidHttpTransport(url);
            androidHttpTransport.debug = true;
		}
        catch(Exception e){
        	System.out.println("Soap Exception---->>>" + e.toString());   
    	}
	}

	
	
	

}
