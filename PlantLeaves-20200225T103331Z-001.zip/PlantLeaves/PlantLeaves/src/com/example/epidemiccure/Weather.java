package com.example.epidemiccure;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class Weather extends Activity {
	private GPS_Tracker gps;
	private String latitude, longitude, lat_long;
	private boolean network;
	ProgressDialog dialog;
	TextView txt1,txt2;
	String result="";
	 String connectionstring="Data Source=64.71.180.27;User ID=opass_123;Password=pass_123"; 
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.weather);
		
		
		txt1=(TextView)findViewById(R.id.textView1);
		txt2=(TextView)findViewById(R.id.textView2);
		
		
		gps = new GPS_Tracker(Weather.this);
		network = NetworkUtil.isNetworkConnectionAvailable(getApplicationContext());
	
		if (gps.canGetLocation()) 
		{
		} 
		else
		{            
			gps.showSettingsAlert();
		}		
		
		
		runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				
				dialog=ProgressDialog.show(Weather.this,"", "Progress....", true);
				
			//	gpsMethod();
				
				Weather1 w = new Weather1();
				w.execute();
			}
		});
		
	}
	
	
	public void gpsMethod() 
	{
		gps = new GPS_Tracker(Weather.this);
		network = NetworkUtil.isNetworkConnectionAvailable(Weather.this);
		if (gps.canGetLocation())
		{
			final double dbl_latitude = gps.getLatitude();
			final double dbl_longitude = gps.getLongitude();

			latitude = String.valueOf(dbl_latitude);
			longitude = String.valueOf(dbl_longitude);

			Toast.makeText(getApplicationContext(), latitude +" " + longitude, Toast.LENGTH_LONG).show();

			lat_long = latitude + "," + longitude;
			Log.d("Message", "Lat & long : " + lat_long);
			runOnUiThread(new Runnable() {
				@Override
				public void run() {
					String str = getAddressFromLocation(dbl_latitude, dbl_longitude, Weather.this);
					//GpsLocation1.setText(str);                       
				}
			});                                                       
		}
		else 
		{   
			gps.showSettingsAlert();
		}
	}

	public String getAddressFromLocation(final double latitude, final double longitude, final Context context) {

		String result = null;
		Geocoder geocoder = new Geocoder(context, Locale.getDefault());

		try {
			List<Address> addressList = geocoder.getFromLocation(latitude, longitude, 1);
			if (addressList != null && addressList.size() > 0) {
				Address address = addressList.get(0);			
			
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < address.getMaxAddressLineIndex(); i++) 
				{
					sb.append(address.getAddressLine(i)).append("\n");
				}
				
				
//				addressList = geocoder.getFromLocation(latitude, longitude, 1);
//                 Log.v("log_tag", "addresses+)_+++" + addressList);
//                String CityName = addressList.get(0).getAddressLine(0);
//				Log.d("City Name : ", CityName);
				
				//sb.append(address.getLocality()).append("\n");
				// sb.append(address.getPostalCode()).append("\n");
				//sb.append(address.get  CountryName());
				result = sb.toString();
				Log.d("Message", "Result : " + result);
			}
		} catch (IOException e) {
			Log.e("Message", "Unable connect to Geocoder", e);
		}
		return result.toString();
	}	
	
	
	class Weather1 extends AsyncTask<String, Void, String>{

		@Override
		protected String doInBackground(String... arg0) {
			Log.d("Current Weather : ", "");
			Webservice com=new Webservice();
			final String result=com.CurrentWeather("Weather");
			dialog.dismiss();
			
			runOnUiThread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
				Toast.makeText(Weather.this, ""+result, Toast.LENGTH_LONG).show();	
				
				String[] res=result.toString().split("~");
				
				txt1.setText("Current Weather : \n\n\t\t\t\t" +res[0].toString());
				txt2.setText("\t\t\t" +res[1].toString());
				
				}
			});	
			return null;
		}
	}	
}
