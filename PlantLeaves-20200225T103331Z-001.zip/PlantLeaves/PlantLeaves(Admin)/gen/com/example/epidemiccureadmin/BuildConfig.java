/** Automatically generated file. DO NOT MODIFY */
package com.example.epidemiccureadmin;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}