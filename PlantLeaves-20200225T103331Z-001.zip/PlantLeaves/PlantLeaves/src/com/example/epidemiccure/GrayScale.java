package com.example.epidemiccure;




import java.io.FileNotFoundException;

import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

@SuppressLint("NewApi")
public class GrayScale extends Activity {
	Bitmap img;
	ImageView img1,img2,i1,i2,i3,i4,i5,i6;
	 final int RQS_IMAGE1 = 1;
	 Uri source;
	   Bitmap bitmapMaster;
	   Canvas canvasMaster;
	   Button b1,b2,b3;
	   private Bitmap bmp;
	   private Bitmap operation;
	   Button btn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.gray_scale);
		img=UploadImage.image;
		img1=(ImageView)findViewById(R.id.imgview1);
	
//		i1=(ImageView)findViewById(R.id.i1);
//		i2=(ImageView)findViewById(R.id.i2);
//		i3=(ImageView)findViewById(R.id.i3);
		i4=(ImageView)findViewById(R.id.i4);
		i5=(ImageView)findViewById(R.id.i5);
		
		img1.setImageBitmap(img);
		
		
		
		
		
		btn=(Button)findViewById(R.id.btnnextseg);
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				Intent i =new Intent(GrayScale.this,Segmentation.class);
				startActivity(i);
				
			}
		});
		
		
//		      b1 = (Button) findViewById(R.id.button1);
//		      b2 = (Button) findViewById(R.id.button2);
//		      b3 = (Button) findViewById(R.id.button3); 
		      BitmapDrawable abmp = (BitmapDrawable) img1.getDrawable();
		      bmp = abmp.getBitmap();
		      
		      
		      operation= Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(),bmp.getConfig());
		      
		      for(int i=0; i<bmp.getWidth(); i++){
		         for(int j=0; j<bmp.getHeight(); j++){
		            int p = bmp.getPixel(i, j);
		            int r = Color.red(p);
		            int g = Color.green(p);
		            int b = Color.blue(p);
		            int alpha = Color.alpha(p);
		            
		            r = 80  +  r;
		            g = 80  + g;
		            b = 80  + b;
		            alpha = 100 + alpha;
		            operation.setPixel(i, j, Color.argb(alpha, r, g, b));
		         }
		      }
		      i4.setImageBitmap(operation);
		      
		      
		      operation= Bitmap.createBitmap(bmp.getWidth(),bmp.getHeight(),bmp.getConfig());
		      
		      for(int i=0; i<bmp.getWidth(); i++){
		         for(int j=0; j<bmp.getHeight(); j++){
		            int p = bmp.getPixel(i, j);
		            int r = Color.red(p);
		            int g = Color.green(p);
		            int b = Color.blue(p);
		            int alpha = Color.alpha(p);
		            
		            r =  r - 50;
		            g =  g - 50;
		            b =  b - 50;
		            alpha = alpha -50;
		            operation.setPixel(i, j, Color.argb(Color.alpha(p), r, g, b));
		         }
		      }
		      i5.setImageBitmap(operation);
		      

		      
		      
		      
//		      Intent intent = new Intent( GrayScale.this,Show.class);
//				PendingIntent pIntent = PendingIntent.getActivity (GrayScale.this, 0, intent, 0);
//				Notification n  = new Notification.Builder( GrayScale.this)
//				        .setContentTitle("Epidemic Cure Diabetic")
//				        .setContentText("Solution Found")
//				        .setSmallIcon(R.drawable.ic_launcher)
//				        .setContentIntent(pIntent)
//				        .setAutoCancel(true)
//				        .build();
//				NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//				Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
//				Ringtone r1 = RingtoneManager.getRingtone(getApplicationContext(), notification);
//				r1.play();
//				notificationManager.notify(0, n); 
//				Vibrator v1 = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
//				v1.vibrate(400);
	
    }
	
	
//	 protected void onActivityResult1(int requestCode, int resultCode, Intent data) {
//	    	super.onActivityResult(requestCode, resultCode, data);
//	    	
//			
//			if (requestCode == RQS_IMAGE1 && resultCode == RESULT_OK && null != data) {
//				Uri selectedImage = data.getData();
//				String[] filePathColumn = { MediaStore.Images.Media.DATA };
//
//				Cursor cursor = getContentResolver().query(selectedImage,
//						filePathColumn, null, null, null);
//				cursor.moveToFirst();
//
//				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
//				String picturePath = cursor.getString(columnIndex);
//				cursor.close();
//				
//				
//				//im.setImageBitmap(BitmapFactory.decodeFile(picturePath));
//			
//			}
//	    
//	    
//	    }
//
//				
				
			
	   
	   @Override
	    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
	    	super.onActivityResult(requestCode, resultCode, data);
	    	
			
			if (resultCode == RESULT_OK) {
				   switch (requestCode) {
				   case RQS_IMAGE1:
				    source = data.getData();

				    try {
				     bitmapMaster = BitmapFactory
				       .decodeStream(getContentResolver().openInputStream(
				         source));
				     loadGrayBitmap(bitmapMaster);

				    } catch (FileNotFoundException e) {
				     // TODO Auto-generated catch block
				     e.printStackTrace();
				    }

				    break;
				   }
				  }
				 }
	   
		 private void loadGrayBitmap(Bitmap src) {
			  if (src != null) {
			   
			   //Array to generate Identity image
			   float[] IdentityArray = {
			     1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			     0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
			     0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
			     0.0f, 0.0f, 0.0f, 1.0f, 0.0f,  
			   };
			   
			   //Array to generate Gray-Scale image
			   float[] GrayArray = {
			     0.213f, 0.715f, 0.072f, 0.0f, 0.0f,
			     0.213f, 0.715f, 0.072f, 0.0f, 0.0f,
			     0.213f, 0.715f, 0.072f, 0.0f, 0.0f,
			     0.0f, 0.0f, 0.0f, 1.0f, 0.0f,  
			   };
			   
			   ColorMatrix colorMatrixGray = new ColorMatrix(GrayArray);

			   int w = src.getWidth();
			   int h = src.getHeight();
			   
			   Bitmap bitmapResult = Bitmap
			     .createBitmap(w, h, Bitmap.Config.ARGB_8888);
			   Canvas canvasResult = new Canvas(bitmapResult);
			   Paint paint = new Paint();
			   
			   ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrixGray);
			   paint.setColorFilter(filter);
			   canvasResult.drawBitmap(src, 0, 0, paint);

			   img2.setImageBitmap(bitmapResult);
			  }
			 }

	   
	   public void bright(View view){
	      operation= Bitmap.createBitmap(bmp.getWidth(), bmp.getHeight(),bmp.getConfig());
	      
	      for(int i=0; i<bmp.getWidth(); i++){
	         for(int j=0; j<bmp.getHeight(); j++){
	            int p = bmp.getPixel(i, j);
	            int r = Color.red(p);
	            int g = Color.green(p);
	            int b = Color.blue(p);
	            int alpha = Color.alpha(p);
	            
	            r = 100  +  r;
	            g = 100  + g;
	            b = 100  + b;
	            alpha = 100 + alpha;
	            operation.setPixel(i, j, Color.argb(alpha, r, g, b));
	         }
	      }
	      i4.setImageBitmap(operation);
	   }
	   
	   public void dark(View view){
	      operation= Bitmap.createBitmap(bmp.getWidth(),bmp.getHeight(),bmp.getConfig());
	      
	      for(int i=0; i<bmp.getWidth(); i++){
	         for(int j=0; j<bmp.getHeight(); j++){
	            int p = bmp.getPixel(i, j);
	            int r = Color.red(p);
	            int g = Color.green(p);
	            int b = Color.blue(p);
	            int alpha = Color.alpha(p);
	            
	            r =  r - 50;
	            g =  g - 50;
	            b =  b - 50;
	            alpha = alpha -50;
	            operation.setPixel(i, j, Color.argb(Color.alpha(p), r, g, b));
	         }
	      }
	      i5.setImageBitmap(operation);
	   }
	   
	   public void gama(View view) {
	      operation = Bitmap.createBitmap(bmp.getWidth(),bmp.getHeight(),bmp.getConfig());
	      
	      for(int i=0; i<bmp.getWidth(); i++){
	         for(int j=0; j<bmp.getHeight(); j++){
	            int p = bmp.getPixel(i, j);
	            int r = Color.red(p);
	            int g = Color.green(p);
	            int b = Color.blue(p);
	            int alpha = Color.alpha(p);
	            
	            r =  r + 150;
	            g =  0;
	            b =  0;
	            alpha = 0;
	            operation.setPixel(i, j, Color.argb(Color.alpha(p), r, g, b));
	         }
	      }
	      i1.setImageBitmap(operation);
	   }
	   
	   public void green(View view){
	      operation = Bitmap.createBitmap(bmp.getWidth(),bmp.getHeight(), bmp.getConfig());
	      
	      for(int i=0; i <bmp.getWidth(); i++){
	         for(int j=0; j<bmp.getHeight(); j++){
	            int p = bmp.getPixel(i, j);
	            int r = Color.red(p);
	            int g = Color.green(p);
	            int b = Color.blue(p);
	            int alpha = Color.alpha(p);
	            
	            r =  0;
	            g =  g+150;
	            b =  0;
	            alpha = 0;
	            operation.setPixel(i, j, Color.argb(Color.alpha(p), r, g, b));
	         }
	      }
	      i2.setImageBitmap(operation);
	   }
	   
	   public void blue(View view){
	      operation = Bitmap.createBitmap(bmp.getWidth(),bmp.getHeight(), bmp.getConfig());
	      
	      for(int i=0; i<bmp.getWidth(); i++){
	         for(int j=0; j<bmp.getHeight(); j++){
	            int p = bmp.getPixel(i, j);
	            int r = Color.red(p);
	            int g = Color.green(p);
	            int b = Color.blue(p);
	            int alpha = Color.alpha(p);
	            
	            r =  0;
	            g =  0;
	            b =  b + 150;
	            alpha = 0;
	            operation.setPixel(i, j, Color.argb(Color.alpha(p), r, g, b));
	         }
	      }
	      i3.setImageBitmap(operation);
	   }

    

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.gray_scale, menu);
		return true;
	}

}
