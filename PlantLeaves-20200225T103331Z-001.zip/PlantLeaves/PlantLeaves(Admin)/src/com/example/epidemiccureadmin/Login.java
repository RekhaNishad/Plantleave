package com.example.epidemiccureadmin;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("NewApi")
@TargetApi(Build.VERSION_CODES.GINGERBREAD)
public class Login extends Activity
{
	//ProgressDialog dialog1;
	EditText txtuser,txtpass;	
	
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		
		 txtuser=(EditText)findViewById(R.id.tuser);
		 txtpass=(EditText)findViewById(R.id.tpass);
	
		Button btnlogin=(Button)findViewById(R.id.btnlog);
		btnlogin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				if((txtuser.getText().toString().trim().equals("admin"))&&(txtpass.getText().toString().trim().equals("pass")))
				{
					//dialog1=ProgressDialog.show(Login.this, "", "In Progress..",true);
					Toast.makeText(Login.this, "Login Successfull", Toast.LENGTH_SHORT).show();
					Intent intent=new Intent(Login.this,Home.class);
					startActivity(intent);
					Login.this.finish();
					
				}
				else
				{
					Toast.makeText(Login.this, "Incorrect Credentials..Please try again!!", Toast.LENGTH_LONG).show();
				}		
			}
			
		});
		
		
	}

}
