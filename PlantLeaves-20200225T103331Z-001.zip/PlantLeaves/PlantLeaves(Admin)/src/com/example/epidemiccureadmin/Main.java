package com.example.epidemiccureadmin;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;


import android.R.integer;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.Bitmap.Config;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Main extends Activity 
{
	File mediaStorageDir;
	EditText etDisease,etSolution,etthresh,etpercentage;
	String disease,solution,thresh,imagename,percentage;
    public static	Button btnUploadImage1;
    Uri selectedImageUri1;
    String picturePath;
	final CharSequence[] options_radio={"Capture from Camera","Choose from Gallery"};
	private String _path;
	public static Bitmap image;
    public static String fname,uploadfilename;
	ProgressDialog dialog;
	ImageView ivUploadImage;
	String croptype;
	String foldername="";
	TextView txtname;
	String connectionstring="Data Source=64.71.180.27;User ID=opass_123;Password=pass_123";   
	String query="";
	
	public static String result2="";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		foldername="PlantLeaves";
		//PlantLeaves
		txtname=(TextView)findViewById(R.id.txtimagename);

		
		ivUploadImage=(ImageView)findViewById(R.id.ivUploadImage);
		ivUploadImage.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
//				AlertDialog.Builder builder2=new AlertDialog.Builder(Main.this)
//				.setTitle("Choose a Color")
//				.setSingleChoiceItems(options_radio, -1, new DialogInterface.OnClickListener() {
//				 
//				@Override
//				public void onClick(DialogInterface dialog, int which) {
//				// TODO Auto-generated method stub
//				
//				if(which==0)
//				{
//					Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//			        // this part to save captured image on provided path
//					File file =  new File(Environment.getExternalStorageDirectory() + "/Android/data/" + getApplicationContext().getPackageName() + "/epidemic/abc.jpg"); 
//					Uri photoPath = Uri.fromFile(file);
//					intent.putExtra(MediaStore.EXTRA_OUTPUT, photoPath);
//	 				// start camera activity
//					int TAKE_PICTURE = 1888; 
//	        		startActivityForResult(intent, 2);
//				}
//				else
//				if(which==1)
//				{
					Intent intent = new Intent();
		            intent.setType("image/*");
		            intent.setAction(Intent.ACTION_GET_CONTENT);
		            startActivityForResult(Intent.createChooser(intent, "Complete action using"), 1);
//				}
//				}
//				});
//				AlertDialog alertdialog2=builder2.create();
//				builder2.show();
			}
		});
		
//		runOnUiThread(new Runnable() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//				DisplayComment();	
//			}
//		});
		
		
		btnUploadImage1=(Button)findViewById(R.id.btnUploadImage1);
		btnUploadImage1.setOnClickListener(new OnClickListener() {
			 
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				
					etDisease=(EditText)findViewById(R.id.etDisease);
					Typeface custom_font1 = Typeface.createFromAsset(getAssets(), "ANKIT.TTF");
					etDisease.setTypeface(custom_font1);
					
					etSolution=(EditText)findViewById(R.id.etSolution);					
					Typeface custom_font = Typeface.createFromAsset(getAssets(), "ANKIT.TTF");
					etSolution.setTypeface(custom_font);
					
					
					//etthresh=(EditText)findViewById(R.id.etthreshold);
					etpercentage=(EditText)findViewById(R.id.etpercentage);
					
					
					disease=etDisease.getText().toString().trim();
					solution=etSolution.getText().toString().trim();
					//thresh=etthresh.getText().toString().trim();
					thresh="0.90".toString().trim();
					imagename=txtname.getText().toString().trim();
					percentage=etpercentage.getText().toString().trim();
					//percentage="80".toString().trim();
					
					Log.e("massage1", ""+solution);
					 Log.e("massage1", ""+disease);
					 Log.e("massage1", ""+thresh);
					 Log.e("massage1", ""+imagename);
					
					storeImage(image);
					new Thread(new Runnable() {
					
						@Override
						public void run() {
							// TODO Auto-generated method stub
							postPhoto();	
							
//							DisplayComment();
							
//							Intent i=new Intent(Main.this, DisplayComment.class);
//							startActivity(i);
						}
					}).start();
				
			}
		});
	}
	
	public String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
	
	public static Bitmap scaleBitmap(Bitmap bitmap, int wantedWidth, int wantedHeight) {
        Bitmap output = Bitmap.createBitmap(wantedWidth, wantedHeight, Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Matrix m = new Matrix();
        m.setScale((float) wantedWidth / bitmap.getWidth(), (float) wantedHeight / bitmap.getHeight());
        canvas.drawBitmap(bitmap, m, new Paint());
        return output;
    }
	
	 private void storeImage(Bitmap image) {
	        File pictureFile = getOutputMediaFile();
	        if (pictureFile == null) {
	            Log.d("Store File",
	                    "Error creating media file, check storage permissions: ");// e.getMessage());
	            return;
	        } 
	        try 
	        {
	            FileOutputStream fos = new FileOutputStream(pictureFile);
	            image.compress(Bitmap.CompressFormat.PNG, 90, fos);
	            Toast.makeText(Main.this, "Path : " +pictureFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();  
	            _path = pictureFile.getAbsolutePath();
	            fos.close();
	        } 
	        catch (FileNotFoundException e) 
	        {
	            Log.d("Store File", "File not found: " + e.getMessage());
	        } 
	        catch (IOException e) 
	        {
	            Log.d("Store File", "Error accessing file: " + e.getMessage());
	        }  
	    }
	  
	 	private  File getOutputMediaFile()
	 	{
	        // To be safe, you should check that the SDCard is mounted
	        // using Environment.getExternalStorageState() before doing this. 
	         mediaStorageDir = new File(Environment.getExternalStorageDirectory() + "/Android/data/" + getApplicationContext().getPackageName() + "/epidemic"); 

	        // This location works best if you want the created images to be shared
	        // between applications and persist after your app has been uninstalled.
	        // Create the storage directory if it does not exist
	        if (! mediaStorageDir.exists()){
	            if (! mediaStorageDir.mkdirs()){
	                return null;
	            }
	        } 
	        // Create a media file name
	        String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
	        File mediaFile;
            mediaFile = new File(mediaStorageDir.getPath() + File.separator+disease+".jpg");
	        return mediaFile;
	    }
	  
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		selectedImageUri1 = data.getData();
	    String[] projection = {MediaStore.Images.Media.DATA};
        try 
        {
	       Cursor cursor = getContentResolver().query(selectedImageUri1, projection, null, null, null);
	       cursor.moveToFirst();
	       int columnIndex = cursor.getColumnIndex(projection[0]);
	       picturePath = cursor.getString(columnIndex);
	       cursor.close();
	       Log.e("Picture Path", picturePath);
	    }
	    catch(Exception e) 
	    {
	       Log.e("Path Error", e.toString());
	    }

        if( resultCode == RESULT_OK)
        { 
        		String  imagepath = getPath(selectedImageUri1);
        		Log.e("imagepath", imagepath);
        		String   _path = imagepath;
        		Log.e("path", _path);
        		image=BitmapFactory.decodeFile(_path);
        		image=BitmapFactory.decodeFile(_path);
        		Toast.makeText(Main.this, "actual path =  " +_path, Toast.LENGTH_LONG).show();
        		File f = new File(_path);
            	String filename = f.getName();
            	fname =filename;
            	txtname.setText(fname);
            	uploadfilename=fname;
            	Log.e("fname", fname);
            	int width = image.getWidth();
                int height = image.getHeight();
                if(width>height)
                {
                	width = 720;
                	height = 480;
                }
                else 
                {
                	width = 480;
                	height = 720;
    			}
                image = scaleBitmap(image, width,height);
        		ivUploadImage.setImageBitmap(image);
        }
	}
	
	public void connnectingwithFTP(String ip, String userName, String pass) {  
        boolean status = false;  
        try {  
        	ip="49.50.76.158";
//        	userName="administrator";
//        	pass="FSD#$%EFsds4t44";
        	userName="ftp_user";
        	pass="ftp@123!!";
        	
            final FTPClient mFtpClient = new FTPClient();  
             mFtpClient.setConnectTimeout(10 * 1000);  
             mFtpClient.connect(InetAddress.getByName(ip));  
             status = mFtpClient.login(userName, pass);  
             Log.e("isFTPConnected", String.valueOf(status));  
             
             if (FTPReply.isPositiveCompletion(mFtpClient.getReplyCode())) {  
                  mFtpClient.setFileType(FTP.ASCII_FILE_TYPE);  
                  mFtpClient.enterLocalPassiveMode();  
                  FTPFile[] mFileArray = mFtpClient.listFiles();  
                  Log.e("Size", String.valueOf(mFileArray.length));  
                  
                  final File file = new File(mediaStorageDir.getPath() + File.separator+disease+".jpg");//_path);
                  mFtpClient.setFileTransferMode(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
                  runOnUiThread(new Runnable() {
  					
  					@Override
  					public void run() {
  						// TODO Auto-generated method stub
  						TextView tvLoading=(TextView)findViewById(R.id.tvLoad);
  						tvLoading.setVisibility(View.VISIBLE);	
  						btnUploadImage1.setEnabled(false);
  					}
  				});
                if(status==true)
                {
                	  new Thread(new Runnable() {
						@Override
						public void run() {
							// TODO Auto-generated method stub
							uploadFile(mFtpClient,file,"/"+foldername+ "/");		
						}
					}).start();
                }
                  
                else
                {
                	 
                }
             }  
        } catch (SocketException e) {  
             e.printStackTrace(); 
             Toast.makeText(Main.this,e.toString(), Toast.LENGTH_SHORT).show();  
        } catch (UnknownHostException e) {  
             e.printStackTrace();  
             Toast.makeText(Main.this,e.toString(), Toast.LENGTH_SHORT).show();    
        } catch (IOException e) {  
             e.printStackTrace();  
//            Toast.makeText(UploadImage.this,e.toString(), Toast.LENGTH_SHORT).show();    
        }  
   }
	
	 private void postPhoto() {
	    	try
		    {
		       FileInputStream is = new FileInputStream(_path);
		        if(_path != null)
		            try{
		            	File f = new File(_path);
		            	String filename = f.getName();
		            	fname =filename;
		            	new Thread(new Runnable() {
		      			    public void run() {
		      			           	 connnectingwithFTP("","","");
		      			    }
		      			  }).start();
	                	  new Thread(new Runnable() {
	          				
	          				@Override
	          				public void run() {
	          					// TODO Auto-generated method stub
	          					//EpidemicCureSolution();
	          					Postnew();
	          				}
	          			}).start();
		            }finally
		            {
		                is.close();
		            }
		    }
	    	catch (Exception e)
		    {
		    
		    }
	   }
	   
	 public void uploadFile(FTPClient ftpClient, File downloadFile,String serverfilePath) {  
         try {  
        	 Log.e("In uploadfile function", "");
        	File f = new File(_path);
        	String filename = f.getName();
        	fname =filename;
              FileInputStream srcFileStream = new FileInputStream(downloadFile);  
              ftpClient.setFileTransferMode(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
              ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE); //must require code for file transfer
//              boolean status = ftpClient.storeFile("httpdocs/"+foldername+"/"+filename,srcFileStream);
              boolean status = ftpClient.storeFile("/"+foldername+"/"+filename,srcFileStream);
              ftpClient.logout();
//              Log.e("path", "httpdocs/"+foldername+"/"+filename);
              Log.e("path", "/"+foldername+"/"+filename);
              Log.e("Status", String.valueOf(status)); 
              srcFileStream.close();
              this.finish();
         } catch (Exception e) {  
              e.printStackTrace(); 
              Toast.makeText(Main.this,e.toString(), Toast.LENGTH_SHORT).show();    
         }  
    }
	 
//	 public void EpidemicCureSolution()
//	 {
//		 WebService web=new WebService();
//		 final String result=web.EpidemicCureSolution("EpidemicCureSolution", disease, solution);
//		 runOnUiThread(new Runnable() {
//			
//			@Override
//			public void run() {
//				// TODO Auto-generated method stub
//			Log.e("EpidemicCureSolution result", result);	
//			Toast.makeText(Main.this, ""+result, Toast.LENGTH_LONG).show();
//			AlertDialog alert=new AlertDialog.Builder(Main.this).create();
//			alert.setMessage(result);
//			}
//		});
	// }
	 
	
	 
	 public void Postnew()
	 {
		 Random r = new Random();
		 int random = r.nextInt(90 - 70) + 70;
		 
		 WebService com=new WebService();
		 String idd1="insert into PlantLeaves_Upload values('" + disease + "','" + solution + "','" + thresh + "','" + imagename + "','" +  random + "')";
		 final String result= com.Employee("CommonQuery",connectionstring, idd1);
		 //dialog.dismiss();
		 query=idd1;
		 runOnUiThread(new Runnable() 
		 {		
			@Override
			public void run() 
			{
			// TODO Auto-generated method stub
		//	Toast.makeText(getApplicationContext(), query, Toast.LENGTH_LONG).show();
				
						
				   }
			});
		}
	 
	 public void DisplayComment()
	 {		 
		 WebService com=new WebService();
		 String idd1="Select * from Plant_Comment1";
		 final String result= com.Employee("SelectQuery1",connectionstring, idd1);
		 result2=result.toString();
		 
		 runOnUiThread(new Runnable() 
		 {		
			@Override
			public void run() 
			{
			// TODO Auto-generated method stub
		     	Toast.makeText(getApplicationContext(), result2, Toast.LENGTH_LONG).show();				
						
			}
		});
	}
}
