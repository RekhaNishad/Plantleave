package com.example.epidemiccure;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.AndroidHttpTransport;

import android.R.string;
import android.util.Log;

public class Webservice {

	private static final String MethodName = null;
	String namespace = "http://tempuri.org/";
    private String url = "http://krivitechnologies.com/Service1.asmx";//"http://www.webservicex.net/ConvertWeight.asmx";
    String SOAP_ACTION;
    SoapObject request = null, objMessages = null;
    SoapSerializationEnvelope envelope;
    AndroidHttpTransport androidHttpTransport;
    
    public Webservice() {
		// TODO Auto-generated constructor stub
	}
    
    private void SetEnvelope() {
		// TODO Auto-generated method stub
		try{
            envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
            envelope.dotNet = true;
            envelope.setOutputSoapObject(request);
            androidHttpTransport = new AndroidHttpTransport(url);
            androidHttpTransport.debug = true;
		}
        catch(Exception e){
        	System.out.println("Soap Exception---->>>" + e.toString());   
    	}
	}
    
    public String Epidemicregistration(String MethodName, String name,String username, String password, String state, String city, String taluka, String mobile, String adhar, String email) 
    {       
      try {
          SOAP_ACTION = namespace + MethodName;
          // SoapObject Request = new SoapObject(name,MethodName);
          //Adding values to request object
          request = new SoapObject(namespace, MethodName);
           
          //Adding Double value to request object
          PropertyInfo weightProp =new PropertyInfo();
          weightProp.setName("name");
          weightProp.setValue(name);
          weightProp.getValue();
          weightProp.setType(String.class);
          request.addProperty(weightProp);
          
          PropertyInfo weightProp1 =new PropertyInfo();
          weightProp1.setName("username");
          weightProp1.setValue(username);
          weightProp1.setType(String.class);
          request.addProperty(weightProp1);
          
           PropertyInfo weightProp2 =new PropertyInfo();
          weightProp2.setName("password");
          weightProp2.setValue(password);
          weightProp2.setType(String.class);
          request.addProperty(weightProp2);
          
           PropertyInfo weightProp3 =new PropertyInfo();
          weightProp3.setName("state");
          weightProp3.setValue(state);
          weightProp3.setType(String.class);
          request.addProperty(weightProp3);           
          
          PropertyInfo weightProp4 =new PropertyInfo();
          weightProp4.setName("city");
          weightProp4.setValue(city);
          weightProp4.setType(String.class);
          request.addProperty(weightProp4);
           
          PropertyInfo weightProp5 =new PropertyInfo();
          weightProp5.setName("taluka");
          weightProp5.setValue(taluka);
          weightProp5.setType(String.class);
          request.addProperty(weightProp5);
        
          PropertyInfo weightProp6 =new PropertyInfo();
          weightProp6.setName("mobile");
          weightProp6.setValue(mobile);
          weightProp6.setType(String.class);
          request.addProperty(weightProp6);
                   
          PropertyInfo weightProp7 =new PropertyInfo();
          weightProp7.setName("adhar");
          weightProp7.setValue(adhar);
          weightProp7.setType(String.class);
          request.addProperty(weightProp7);          
          
          PropertyInfo weightProp8 =new PropertyInfo();
          weightProp8.setName("email");
          weightProp8.setValue(email);
          weightProp8.setType(String.class);
          request.addProperty(weightProp8);                    
          
          SetEnvelope(); 
           
          try {
               
              //SOAP calling webservice
              androidHttpTransport.call(SOAP_ACTION, envelope);
               
              //Got Webservice response
              String result = envelope.getResponse().toString();

              return result;
               
          } catch (Exception e) {
              // TODO: handle exception
              return e.toString();
          }
      } catch (Exception e) {
          // TODO: handle exception
          return e.toString();
      }
  }
    
    
    public String Employee(String MethodName,String connectionstring,String Query) 
    {      
      try
      {
          SOAP_ACTION = namespace + MethodName;
          // SoapObject Request = new SoapObject(name,MethodName);
          //Adding values to request object
          request = new SoapObject(namespace, MethodName);
           
          //Adding Double value to request object
          PropertyInfo weightProp =new PropertyInfo();
          weightProp.setName("connectionstring");
          weightProp.setValue(connectionstring);
          weightProp.getValue();
          weightProp.setType(String.class);
          request.addProperty(weightProp);
               
          PropertyInfo weightProp1 =new PropertyInfo();
          weightProp1.setName("Query");
          weightProp1.setValue(Query);
          weightProp1.setType(String.class);
          request.addProperty(weightProp1);  
          
          SetEnvelope();
           
          try {               
              //SOAP calling webservice
              androidHttpTransport.call(SOAP_ACTION, envelope);
              //Got Webservice response
              String result = envelope.getResponse().toString();
              return result;
          } catch (Exception e) {
              // TODO: handle exception
              return e.toString();
          }
      } catch (Exception e) {
          // TODO: handle exception
          return e.toString();
      }
  }  
    
    
    public String epidemicogin(String MethodName,String username, String password)
    {
    	try
    	{
    		SOAP_ACTION = namespace + MethodName;
            request = new SoapObject(namespace, MethodName);            
           
            PropertyInfo weightProp3 =new PropertyInfo();
            weightProp3.setName("username");
            weightProp3.setValue(username);
            weightProp3.setType(string.class);
            request.addProperty(weightProp3);
            
            PropertyInfo weightProp4 =new PropertyInfo();
            weightProp4.setName("password");
            weightProp4.setValue(password);
            weightProp4.setType(string.class);
            request.addProperty(weightProp4);
    		
    		SetEnvelope();
            
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                String result = envelope.getResponse().toString();
                return result;
            } 
            catch (Exception e) {
           	return e.toString();
            }            
    	}
    	catch (Exception e) {
            return e.toString();
        }
    }
    public String epidemicretriveuser(String MethodName)
    {
    	try
    	{
    		SOAP_ACTION = namespace + MethodName;
            request = new SoapObject(namespace, MethodName);
            
    		SetEnvelope();
            
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                String result = envelope.getResponse().toString();
                return result;
            } 
            catch (Exception e) {
           	return e.toString();
            }
            
    	}
    	catch (Exception e) {
            return e.toString();
        }
    }
    
    public String epidemicCntComment(String MethodName)
    {
    	try
    	{
    		SOAP_ACTION = namespace + MethodName;
            request = new SoapObject(namespace, MethodName);
            
    		SetEnvelope();
            
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                String result = envelope.getResponse().toString();
                return result;
            } 
            catch (Exception e) {
           	return e.toString();
            }
            
    	}
    	catch (Exception e) {
            return e.toString();
        }
    }
    
    public String epicComment(String MethodName,String id)
    {
    	try
    	{
    		SOAP_ACTION = namespace + MethodName;
            request = new SoapObject(namespace, MethodName);            
           
            PropertyInfo weightProp1 =new PropertyInfo();
            weightProp1.setName("id");
            weightProp1.setValue(id);
            weightProp1.setType(string.class);
            request.addProperty(weightProp1);  
    		
    		SetEnvelope();
            
            try 
            {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                String result = envelope.getResponse().toString();
                return result;
            } 
            catch (Exception e) {
           	return e.toString();
            }            
    	}
    	catch (Exception e) {
            return e.toString();
        }
    }
    
    public String epidemicComment(String MethodName, String comments, String name, String date)
    {
    	try
    	{
    		SOAP_ACTION = namespace + MethodName;
            request = new SoapObject(namespace, MethodName);
            
            PropertyInfo weightProp2 =new PropertyInfo();
            weightProp2.setName("comments");
            weightProp2.setValue(comments);
            weightProp2.setType(string.class);
            request.addProperty(weightProp2);
            
            PropertyInfo weightProp3 =new PropertyInfo();
            weightProp3.setName("name");
            weightProp3.setValue(name);
            weightProp3.setType(string.class);
            request.addProperty(weightProp3);
            
            PropertyInfo weightProp4 =new PropertyInfo();
            weightProp4.setName("date");
            weightProp4.setValue(date);
            weightProp4.setType(string.class);
            request.addProperty(weightProp4);
    		
    		SetEnvelope();
            
            try {
                androidHttpTransport.call(SOAP_ACTION, envelope);
                String result = envelope.getResponse().toString();
                return result;
            } 
            catch (Exception e) {
           	return e.toString();
            }            
    	}
    	catch (Exception e) {
            return e.toString();
        }
    }
    
    
    
    public String CurrentWeather(String MethodName) 
    {       
      try {
          SOAP_ACTION = namespace + MethodName;
          // SoapObject Request = new SoapObject(name,MethodName);
          //Adding values to request object
          request = new SoapObject(namespace, MethodName);
           
                          
          
          SetEnvelope(); 
           
          try {
               
              //SOAP calling webservice
              androidHttpTransport.call(SOAP_ACTION, envelope);
               
              //Got Webservice response
              String result = envelope.getResponse().toString();

              return result;
               
          } catch (Exception e) {
              Log.d("Message", "Error 1 : "+e);
              return e.toString();
          }
      } catch (Exception e) {
    	  Log.d("Message", "Error 2 : "+e);
          return e.toString();
      }
  }
}
