package com.example.epidemiccure;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class UploadImage extends Activity 
{
	public static	Button btnUploadImage1;
	final CharSequence[] options_radio={"Capture from Camera","Choose from Gallery"};
	private String _path;
	public static Bitmap image;
	String fname;
	ProgressDialog dialog;
	ImageView ivUploadImage;
	   ImageView iv;
	public static  String category="fruits";
	public static  String threshold="0.25";
	EditText etThreshold;
	  private Bitmap bmp;
	   private Bitmap operation;
	   TextView txt;
	   final int RQS_IMAGE1 = 1;
	   public static String filename1="";
   String idd1,result;
	   Uri source;
	   Bitmap bitmapMaster;
	   Canvas canvasMaster;
	   public static String newthresh="";
	   
		 String connectionstring="Data Source=64.71.180.27;User ID=opass_123;Password=pass_123"; 
	   
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.uploadimage);
      //  txt=(TextView)findViewById(R.id.txtthreshold);
       
		iv=(ImageView)findViewById(R.id.iv1);
	//	etThreshold=(EditText)findViewById(R.id.etThreshold);
		
		
		
		ivUploadImage=(ImageView)findViewById(R.id.ivUploadImage);
		
		ivUploadImage.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				

					
					
					Intent intent = new Intent();
		            intent.setType("image/*");
		            intent.setAction(Intent.ACTION_GET_CONTENT);
		            startActivityForResult(Intent.createChooser(intent, "Complete action using"), 1);

	           
			}
		});
		
		
		btnUploadImage1=(Button)findViewById(R.id.btnUploadImage1);
		btnUploadImage1.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				dialog = ProgressDialog.show(UploadImage.this,"","Uploading Image....",true);
				//threshold=etThreshold.getText().toString().trim();
				//Toast.makeText(UploadImage.this, threshold.trim(), Toast.LENGTH_LONG).show();
				
			
					
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						//Postnew();
						postPhoto();	
					
					}
				}).start();
					}
					
			
		});
		
//		txt=(TextView)findViewById(R.id.txtthreshold);
//		txt.setOnClickListener(new OnClickListener() {
//			
//			@Override
//			public void onClick(View arg0) {
//				// TODO Auto-generated method stub
//				
//              new Thread(new Runnable() {
//					
//					@Override
//					public void run() {
//						// TODO Auto-generated method stub
//						Postnew();		
//					}
//				}).start();
//				
//			}
//		});
		

	}
	


	     
	public String getPath(Uri uri) {
        String[] projection = { MediaStore.Images.Media.DATA };
        Cursor cursor = managedQuery(uri, projection, null, null, null);
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(column_index);
    }
	public static Bitmap scaleBitmap(Bitmap bitmap, int wantedWidth, int wantedHeight) {
        Bitmap output = Bitmap.createBitmap(wantedWidth, wantedHeight, Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Matrix m = new Matrix();
        m.setScale((float) wantedWidth / bitmap.getWidth(), (float) wantedHeight / bitmap.getHeight());
      
       // photo.compress(CompressFormat.JPEG, 25, bos); 
        
        canvas.drawBitmap(bitmap, m, new Paint());

        return output;
    }
	 private void storeImage(Bitmap image) {
	        File pictureFile = getOutputMediaFile();
	        if (pictureFile == null) {
	            Log.d("Store File",
	                    "Error creating media file, check storage permissions: ");// e.getMessage());
	            return;
	        } 
	        try {
	            FileOutputStream fos = new FileOutputStream(pictureFile);
	            image.compress(Bitmap.CompressFormat.PNG, 90, fos);
	            Toast.makeText(UploadImage.this,pictureFile.getAbsolutePath(), Toast.LENGTH_SHORT).show();  
	            _path = pictureFile.getAbsolutePath();
	            fos.close();
	        } catch (FileNotFoundException e) {
	            Log.d("Store File", "File not found: " + e.getMessage());
	        } catch (IOException e) {
	            Log.d("Store File", "Error accessing file: " + e.getMessage());
	        }  
	    }
	  private  File getOutputMediaFile(){
	        // To be safe, you should check that the SDCard is mounted
	        // using Environment.getExternalStorageState() before doing this. 
	        File mediaStorageDir = new File(Environment.getExternalStorageDirectory()
	                + "/Android/data/"
	                + getApplicationContext().getPackageName()
	                + "/Files"); 

	        // This location works best if you want the created images to be shared
	        // between applications and persist after your app has been uninstalled.

	        // Create the storage directory if it does not exist
	        if (! mediaStorageDir.exists()){
	            if (! mediaStorageDir.mkdirs()){
	                return null;
	            }
	        } 
	        // Create a media file name
	        String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmm").format(new Date());
	        File mediaFile;
	            String mImageName="abc.jpg";
	            mediaFile = new File(mediaStorageDir.getPath() + File.separator + filename1+"abc.jpg");  
	        return mediaFile;
	    } 
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		//uiHelper.onActivityResult(requestCode, resultCode, data, dialogCallback);
        
        if (requestCode == 1 && resultCode == RESULT_OK) {
            //Bitmap photo = (Bitmap) data.getData().getPath(); 
           
            Uri selectedImageUri = data.getData();
          String  imagepath = getPath(selectedImageUri);
          _path = imagepath;
            image=BitmapFactory.decodeFile(_path);
            
            int width = image.getWidth();
            int height = image.getHeight();
            
            if(width>height)
            {
            	width = 720;
            	height = 480;
            	
            			
            }
            else {
            	width = 480;
            	height = 720;
			}
            
            image = scaleBitmap(image, width,height);
          
            ivUploadImage.setImageBitmap(image);
            storeImage(image);
            
            Uri selectedImageUri1 = data.getData();
      		 String  imagepath1 = getPath(selectedImageUri1);
               File f1 = new File(imagepath);
            filename1 = f1.getName();
               Log.e("image name", filename1); 
             //  Toast.makeText(getApplicationContext(), ""+filename1, Toast.LENGTH_LONG).show();
            

	    	super.onActivityResult(requestCode, resultCode, data);
	    	
			
			if (resultCode == RESULT_OK) {
				   switch (requestCode) {
				   case RQS_IMAGE1:
				    source = data.getData();

				    try {
				     bitmapMaster = BitmapFactory
				       .decodeStream(getContentResolver().openInputStream(
				         source));
				     loadGrayBitmap(bitmapMaster);

				    } catch (FileNotFoundException e) {
				     // TODO Auto-generated catch block
				     e.printStackTrace();
				    }

				    break;
				   }
				  }
				 
            
        }
        else
        	if(requestCode == 2 && resultCode == RESULT_OK)
        {
        		String _path=Environment.getExternalStorageDirectory()
                        + "/Android/data/"
                        + getApplicationContext().getPackageName()
                        + "/Files/abc.jpg";
        		
        		//Uri uri=Uri.parse(_path);
        		image=BitmapFactory.decodeFile(_path);
        		Toast.makeText(UploadImage.this, ""+_path, Toast.LENGTH_LONG).show();
        		File f = new File(_path);
            	String filename = f.getName();
            	fname =filename;
            	Log.e("fname", fname);
            	int width = image.getWidth();
                int height = image.getHeight();
                
                if(width>height)
                {
                	width = 720;
                	height = 480;
                	
                			
                }
                else {
                	width = 480;
                	height = 720;
    			}
                image = scaleBitmap(image, width,height);
        		ivUploadImage.setImageBitmap(image);
        		storeImage(image);
        		
        		
        		 Uri selectedImageUri1 = data.getData();
        		 String  imagepath = getPath(selectedImageUri1);
                 File f1 = new File(imagepath);
             	 filename1 = f1.getName();
                 Log.e("image name", filename1); 
         //        Toast.makeText(getApplicationContext(), "its another"+filename1, Toast.LENGTH_LONG).show();
                // foo = filename1.substring(0, fname.lastIndexOf('.'));

        }
	}
	public void connnectingwithFTP(String ip, String userName, String pass) {  
        boolean status = false;  
        try {  
        	ip="49.50.76.158";
//        	userName="administrator";
//        	pass="FSD#$%EFsds4t44";
        	userName="ftp_user";
        	pass="ftp@123!!";
            final FTPClient mFtpClient = new FTPClient();  
             mFtpClient.setConnectTimeout(10 * 1000);  
             mFtpClient.connect(InetAddress.getByName(ip));  
             status = mFtpClient.login(userName, pass);  
             Log.e("isFTPConnected", String.valueOf(status));  
             if (FTPReply.isPositiveCompletion(mFtpClient.getReplyCode())) {  
                  mFtpClient.setFileType(FTP.ASCII_FILE_TYPE);  
                  mFtpClient.enterLocalPassiveMode();  
                  FTPFile[] mFileArray = mFtpClient.listFiles();  
                  Log.e("Size", String.valueOf(mFileArray.length));  
                  
                 final File file = new File(_path);
                  mFtpClient.setFileTransferMode(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
                 // dialog = ProgressDialog.show(HelloFacebookSampleActivity.this, "", "Uploading file...", true);
                  runOnUiThread(new Runnable() {
  					
  					@Override
  					public void run() {
  						// TODO Auto-generated method stub
  						TextView tvLoading=(TextView)findViewById(R.id.tvLoad);
  						tvLoading.setVisibility(View.VISIBLE);	
  						btnUploadImage1.setEnabled(false);
  					}
  				});
                  dialog.dismiss();
              
                  if(status==true)
                  {
                	  new Thread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							uploadFile(mFtpClient,file,"/epidemicimage/");		
						}
					}).start();                	  
                  }                  
                  else
                  {
                	 
                  }
             }  
            
             
        } catch (SocketException e) {  
             e.printStackTrace(); 
             Toast.makeText(UploadImage.this,e.toString(), Toast.LENGTH_SHORT).show();  
        } catch (UnknownHostException e) {  
             e.printStackTrace();  
             Toast.makeText(UploadImage.this,e.toString(), Toast.LENGTH_SHORT).show();    
        } catch (IOException e) {  
             e.printStackTrace();  
             Toast.makeText(UploadImage.this,e.toString(), Toast.LENGTH_SHORT).show();    
        }  
   } 
	 private void postPhoto() {
	    	//Log.e("In postphoto()	", _path);
	    
	    	try
		    {
		       FileInputStream is = new FileInputStream(_path);
		        if(_path != null)
		            try{
		            
		            	File f = new File(_path);
		            	String filename = f.getName();
		            	fname =filename;
		            	
		            	new Thread(new Runnable() {
		      			    public void run() {
		      			           	 connnectingwithFTP("","","");
		      					
		      			    }
		      			  }).start();
		                
		            }finally{
		            	 
		                is.close();
		            }
		    }catch (Exception e)
		    {
		    	 Toast.makeText(UploadImage.this,e.toString(), Toast.LENGTH_SHORT).show();
		    }
	   }
	   
	 public void uploadFile(FTPClient ftpClient, File downloadFile,String serverfilePath) {  
         try {  
        	 Log.e("In uploadfile function", "");
        	File f = new File(_path);
        	String filename = f.getName();
        	fname =filename;
        	
              FileInputStream srcFileStream = new FileInputStream(downloadFile);  
              ftpClient.setFileTransferMode(org.apache.commons.net.ftp.FTP.BINARY_FILE_TYPE);
              ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE); //must require code for file transfer
              boolean status = ftpClient.storeFile("/epidemicimage/"+filename,srcFileStream);  
              ftpClient.logout();
             // dialog.dismiss();
              
              Log.e("Status", String.valueOf(status));  
              srcFileStream.close();
              
              Intent intent=new Intent(UploadImage.this,GrayScale.class);
              startActivity(intent);
                     			
//              Intent intent=new Intent(UploadImage.this,DisplayImage.class);
//              startActivity(intent);
              
	                this.finish();
	         
         } catch (Exception e) {  
              e.printStackTrace(); 
              Toast.makeText(UploadImage.this,e.toString(), Toast.LENGTH_SHORT).show();    
           
         }    
    }

				 private void loadGrayBitmap(Bitmap src) {
				  if (src != null) {
				   
			   //Array to generate Identity image
				   float[] IdentityArray = {
				     1.0f, 0.0f, 0.0f, 0.0f, 0.0f,
			     0.0f, 1.0f, 0.0f, 0.0f, 0.0f,
				     0.0f, 0.0f, 1.0f, 0.0f, 0.0f,
				     0.0f, 0.0f, 0.0f, 1.0f, 0.0f,  
				   };
				   
				   //Array to generate Gray-Scale image
				   float[] GrayArray = {
				     0.213f, 0.715f, 0.072f, 0.0f, 0.0f,
				     0.213f, 0.715f, 0.072f, 0.0f, 0.0f,
				     0.213f, 0.715f, 0.072f, 0.0f, 0.0f,
				     0.0f, 0.0f, 0.0f, 1.0f, 0.0f,  
				   };
				   
				  
				   
				   ColorMatrix colorMatrixGray = new ColorMatrix(GrayArray);

				   int w = src.getWidth();
				   int h = src.getHeight();
				   
				   Bitmap bitmapResult = Bitmap
				     .createBitmap(w, h, Bitmap.Config.ARGB_8888);
				   Canvas canvasResult = new Canvas(bitmapResult);
				   Paint paint = new Paint();
				   
				   ColorMatrixColorFilter filter = new ColorMatrixColorFilter(colorMatrixGray);
				   paint.setColorFilter(filter);
				   canvasResult.drawBitmap(src, 0, 0, paint);
   
				   iv.setImageBitmap(bitmapResult);
				  }
				 }
				 
//				 
				 public void Postnew()
					{		
					//Toast.makeText(getApplication(), ""+filename1, Toast.LENGTH_LONG).show();
					    
							Webservice com=new Webservice();
							 idd1="select thresh from PlantLeaves_Upload where imagename='"+ filename1 +"'";
							 result= com.Employee("SelectQuery",connectionstring, idd1);
							// Toast.makeText(getApplication(), ""+filename1, Toast.LENGTH_LONG).show();
							
							//dialog.dismiss();
							runOnUiThread(new Runnable() {		
								@Override
								public void run() {
						
								newthresh=result.trim().toString();
							//	Toast.makeText(getApplicationContext(), ""+newthresh, Toast.LENGTH_LONG).show();
//									

									
							   }
						});
					} 

			

}
