package com.example.epidemiccure;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends Activity implements OnClickListener{
	 String users;
	EditText txt2;
    AutoCompleteTextView txt1;
	Button btn;
	String pass;
	public static String user;
	ProgressDialog dialog,dialog1;
	String result;
	Button weather;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				RetrieveUserNames();
			}
		}).start();
				
		txt1=(AutoCompleteTextView)findViewById(R.id.editText1);
		txt2 = (EditText)findViewById(R.id.editText2);
		btn = (Button)findViewById(R.id.button1);
		btn.setOnClickListener(this);
		TextView tvRegiser=(TextView)findViewById(R.id.tvRegister);
		tvRegiser.setText(Html.fromHtml("<u>"+"Register Now?"+"</u>"));
		tvRegiser.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
			Intent intentregister=new Intent(Login.this,Registration.class);
			startActivity(intentregister);
			}
		});
		
		
		
		weather=(Button)findViewById(R.id.btn_Weather);
		weather.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent i=new Intent(Login.this,Weather.class);
				startActivity(i);
				
			}
		});
		
	}
	
	public void RetrieveUserNames()
	{
		Webservice web=new Webservice();
		users=web.epidemicretriveuser("epidemicretriveuser");
		//dialog1.dismiss();
		runOnUiThread(new Runnable() {
	
			@Override
			public void run() {
				// TODO Auto-generated method stub
				Log.e("Retrieved names", users);
				//	txt1 = (AutoCompleteTextView)findViewById(R.id.editText1);
				String[] userssplit=users.split(":");
				Log.e("Retrieved names length",String.valueOf(userssplit.length));
				//ArrayAdapter<String> adapter=new ArrayAdapter<String>(Login.this,android.R.layout.simple_dropdown_item_1line,userssplit);
				//txt1.setAdapter(adapter);
		
				ArrayAdapter<String> adapter=new ArrayAdapter<String>(Login.this,android.R.layout.simple_dropdown_item_1line,userssplit);
				txt1.setAdapter(adapter);
			}
		});
	}
	
	@Override
	public void onClick(View arg0) {
		
				user = txt1.getText().toString();
		pass = txt2.getText().toString();
		dialog=ProgressDialog.show(Login.this, "","Loading.." ,true);
		new Thread(new Runnable() {
			
	@Override
	public void run() {
				
				login();
			}
		}).start();
		
	}
	
	
	public void login()
	{
			Webservice web=new Webservice();
			result=web.epidemicogin("PlantLeaves_Login", user, pass) ;
			dialog.dismiss();
			runOnUiThread(new Runnable() {
				
				@SuppressLint("NewApi")
				@Override
				public void run() {
					// TODO Auto-generated method stub
					Toast.makeText(Login.this, ""+result, Toast.LENGTH_SHORT).show();
					if(result.toLowerCase().trim().equals("login successfull"))
					{
						Intent intent=new Intent(Login.this,UploadImage.class);
						startActivity(intent);
					}
					else
					{
						//Toast.makeText(Login.this, ""+result, Toast.LENGTH_LONG).show();
					}
				}
			});
			
		}
}
