package com.example.epidemiccureadmin;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.view.Menu;
import android.widget.TextView;

public class Splash extends Activity implements Runnable{

	public static  String functionresultchat="";
	public static int datalengthc=0;
	private static final int NOT_ID = 0;
	StringBuffer stringBufferchat = new StringBuffer();  
	TextView tv;
	Thread t;
	boolean flag=true;
	static Context context;
	ConnectivityManager connectivityManager;
	NetworkInfo wifiInfo, mobileInfo;
	boolean connected = false;
	ProgressDialog dialog;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		String filenamechatlength="chatlengthfile";  
		  File filelength = getBaseContext().getFileStreamPath(filenamechatlength);
		  
		  if (filelength.exists())
		  {
		    	filelength.delete();
		  }
      
	      FileOutputStream fosregister;  
	      try {  
	          	  String type=datalengthc+"";
	           	  fosregister = openFileOutput(filenamechatlength, Context.MODE_PRIVATE);  
	              fosregister.write(type.getBytes());  
	           	  fosregister.close();  
	          } 
	      catch (FileNotFoundException e) 
	      {
	    	  e.printStackTrace();
	      }  
	
	     catch (IOException e) 
	     {
	    	 e.printStackTrace();
	   	 }  
	    
		t=new Thread(this,"");
		t.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splash, menu);
		return true;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try
		{
			t.sleep(500);
			Intent intent=new Intent(this,Login.class);
			startActivity(intent);
			this.finish();
			dialog.dismiss();
		}
		catch(Exception ex){}
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		this.finish();
	}

}
