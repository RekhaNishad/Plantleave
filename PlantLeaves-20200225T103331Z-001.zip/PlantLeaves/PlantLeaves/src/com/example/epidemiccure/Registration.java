package com.example.epidemiccure;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Registration extends Activity{
ProgressDialog dialog;
	EditText etName,etUname,etPass,etState,etCity,etTaluka,etMobile,etAdhar,etEmail;
	String name,uname,pass,state,city,taluka,mobile,adhar,email;
	int flag=0;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.registration);
		Button btnRegister=(Button)findViewById(R.id.btnRegister);
		btnRegister.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				etName=(EditText)findViewById(R.id.etName);
				etUname=(EditText)findViewById(R.id.etUName);
				etPass=(EditText)findViewById(R.id.etPass);
				etState=(EditText)findViewById(R.id.etState);
				etCity=(EditText)findViewById(R.id.etCity);
				etTaluka=(EditText)findViewById(R.id.etTaluka);
				etMobile=(EditText)findViewById(R.id.etMobile);
			    etAdhar=(EditText)findViewById(R.id.etadhar);
				etEmail=(EditText)findViewById(R.id.etemail);
				
				
				
				name=etName.getText().toString();
				uname=etUname.getText().toString();
				pass=etPass.getText().toString();
				state=etState.getText().toString();
				city=etCity.getText().toString();
				taluka=etTaluka.getText().toString();
				mobile=etMobile.getText().toString();
				adhar=etAdhar.getText().toString();
				email=etEmail.getText().toString();
				
				Validate();
				if(flag==1)
				{
				dialog=ProgressDialog.show(Registration.this,"", "Registration in Progress....", true);
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						register();
					}
				}).start();
				}
				else
				{
					//Toast.makeText(Registration.this, "Please fill the fields", Toast.LENGTH_LONG).show();
				}
			}
		});
		
		
	}
	public void Validate()
	{
		if(etName.getText().length()==0)
			etName.setError("Name is Mandatory");
		
		if(etUname.getText().length()==0)
			etUname.setError("Username is Mandatory");
		
		if(etPass.getText().length()==0)
			etPass.setError("Password is Mandatory");
		
		if(etMobile.getText().length()==0)
		
			etMobile.setError("Phone Number is Mandatory");
		
		Pattern pattern =Patterns.PHONE; //Pattern.compile("\\d{3}-\\d{7}");
	      Matcher matcher = pattern.matcher(etMobile.getText());
	 
	      if (matcher.matches()) {
	    	  System.out.println("Phone Number Valid");
	      }
	      else
	      {
	    	  //System.out.println("Phone Number must be in the form XXX-XXXXXXX");
	    	  etMobile.setError("Invalid Mobile Number");
	    	  flag=0;
	      }
		if((etName.getText().length()==0)||(etUname.getText().length()==0)||(etPass.getText().length()==0)||(etMobile.getText().length()==0))
		{
			flag=0;
		}
		
		
		else
		{
			flag=1;
		}
					
	}
	
	public void register()
	{
		Webservice com=new Webservice();
		final String result=com.Epidemicregistration("PlantLeaves_Registration", name, uname, pass, state, city, taluka, mobile, adhar, email);
		dialog.dismiss();
		
		runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
			Toast.makeText(Registration.this, ""+result, Toast.LENGTH_LONG).show();	
			if(result.toLowerCase().trim().equals("registration completed"))
			{
				 
				String filedata=uname+","+mobile+","+city; 
				String filename="agriregister"; 
	                FileOutputStream fos1;  
	                   try {  
	                    fos1 = openFileOutput(filename, Context.MODE_PRIVATE);  
	                    //default mode is PRIVATE, can be APPEND etc.  
	                    fos1.write(filedata.getBytes());  
	                    fos1.close();  
	                     
	                   // Toast.makeText(getApplicationContext(),filename + " saved",  
	                     //       Toast.LENGTH_LONG).show();  
	                      
	                    
	                   } catch (FileNotFoundException e) {e.printStackTrace();}  
	                   catch (IOException e) {e.printStackTrace();}  
	                  Intent intent=new Intent(Registration.this,Login.class);
	                  startActivity(intent);
	                  
	       
			}
			else
			{
			Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_LONG).show();
			}
			}
		});
		
	}
	
}
