package com.example.epidemiccureadmin;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class Home extends Activity implements OnClickListener{
Button btnupload,btncomment;
public static String result2="";
Button SendSMS;
String connectionstring="Data Source=64.71.180.27;User ID=opass_123;Password=pass_123"; 

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.home);
		
		runOnUiThread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				DisplayComment();	
			}
		});
		
	btnupload=(Button)findViewById(R.id.btn_upimage);
	btnupload.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i=new Intent(Home.this, Main.class);
			startActivity(i);
		}
	});
	
	
	
	btncomment=(Button)findViewById(R.id.btn_dispcomment);
	btncomment.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			Intent i=new Intent(Home.this, DisplayComment.class);
			startActivity(i);
		}
	});
	
	
	SendSMS= (Button)findViewById(R.id.btn_SMS3);
	SendSMS.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			Intent i=new Intent(Home.this, SMS.class);
			startActivity(i);
			
		}
	});
	
	
	}
	
	
	 public void DisplayComment()
	 {		 
		 WebService com=new WebService();
		 String idd1="Select * from Plant_Comment1";
		 final String result= com.Employee("SelectQuery1",connectionstring, idd1);
		 result2=result.toString();
		 
		 runOnUiThread(new Runnable() 
		 {		
			@Override
			public void run() 
			{
			// TODO Auto-generated method stub
		     	Toast.makeText(getApplicationContext(), result2, Toast.LENGTH_LONG).show();				
						
			}
		});
	}
	

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

}
