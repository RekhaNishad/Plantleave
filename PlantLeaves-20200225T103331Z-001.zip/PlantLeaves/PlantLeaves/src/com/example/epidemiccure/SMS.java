package com.example.epidemiccure;



import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SMS extends Activity implements OnClickListener{

	EditText mobileno,message1;
	Button sendsms;
	Context context;
	public static String mobile ="";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sms);
		
		
		mobileno=(EditText)findViewById(R.id.txt_mobileno);
		message1=(EditText)findViewById(R.id.txt_messages);
		sendsms=(Button)findViewById(R.id.btn_SendSMS);
		sendsms.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				mobile = mobileno.getText().toString();   
				Sendsms(mobile);
				
			}
		});		
	}


	
	
	public void Sendsms(String numbers)
	{
        String message = message1.getText().toString();
        Uri sendSmsTo = Uri.parse("smsto:" + numbers);
        Intent intent = new Intent(android.content.Intent.ACTION_SENDTO, sendSmsTo);
        intent.putExtra("sms_body", message);
        startActivity(intent);
       // Toast.makeText(getApplicationContext(), "Message Send", Toast.LENGTH_LONG).show();
        
    }
	
	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		
	}

	
	

}
